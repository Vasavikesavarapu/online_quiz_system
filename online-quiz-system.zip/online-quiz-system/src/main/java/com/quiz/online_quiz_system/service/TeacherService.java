package com.quiz.online_quiz_system.service;

import com.quiz.online_quiz_system.entity.Quiz;
import com.quiz.online_quiz_system.entity.Teacher;
import com.quiz.online_quiz_system.repository.QuizRepository;
import com.quiz.online_quiz_system.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeacherService {

    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private QuizRepository quizRepository;

    // Create quiz
    public Quiz createQuiz(Quiz quiz) {
        return quizRepository.save(quiz);
    }

    // Get teacher by email
    public Teacher getTeacherByEmail(String email) {
        return teacherRepository.findByEmail(email);
    }

    // Get quizzes by teacher
    public List<Quiz> getQuizzesByTeacher(int teacherId) {
        return quizRepository.findAll(); // later filter by teacherId
    }
}
