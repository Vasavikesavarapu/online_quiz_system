package com.quiz.online_quiz_system.service;

import com.quiz.online_quiz_system.entity.OTP;
import com.quiz.online_quiz_system.repository.OTPRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;
    @Autowired
    private OTPRepository otpRepository;

    @Transactional
    public void deleteAndSaveOTP(String email, String otp, LocalDateTime expiryTime) {
        otpRepository.deleteByEmail(email);
        otpRepository.save(new OTP(email, otp, expiryTime));
    }
    public void sendOTP(String toEmail, String otp) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(toEmail);
        message.setSubject("Password Reset OTP");
        message.setText("Your OTP for password reset is: " + otp + "\n\nThis OTP will expire in 10 minutes.");
        message.setFrom("vasavikesavarapu13@gmail.com");
        mailSender.send(message);
    }
    @Transactional
    public void deleteOTP(String email) {
        otpRepository.deleteByEmail(email);
    }
}
