package com.quiz.online_quiz_system.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "student_answer")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class StudentAnswer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "attempt_id",nullable = false)
    @ToString.Exclude
    @JsonBackReference
    private QuizAttempt quizAttempt;

    @ManyToOne
    @JoinColumn(name = "question_id",nullable = false)
    private Question question;

    @Column(nullable = false)
    private String answer;

    @Column(nullable = false)
    private boolean isCorrect;
}



