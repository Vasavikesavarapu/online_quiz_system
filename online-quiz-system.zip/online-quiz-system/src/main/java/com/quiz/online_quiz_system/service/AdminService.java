package com.quiz.online_quiz_system.service;
import com.quiz.online_quiz_system.entity.Student;
import com.quiz.online_quiz_system.entity.Teacher;
import com.quiz.online_quiz_system.repository.AdminRepository;
import com.quiz.online_quiz_system.repository.StudentRepository;
import com.quiz.online_quiz_system.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.quiz.online_quiz_system.entity.Admin;
import java.util.List;



@Service
public class AdminService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private AdminRepository adminRepository;

    // Add student
    public Student addStudent(Student student) {
        return studentRepository.save(student);
    }

    // Add teacher
    public Teacher addTeacher(Teacher teacher) {
        return teacherRepository.save(teacher);
    }

    // Get all students
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    // Get all teachers
    public List<Teacher> getAllTeachers() {
        return teacherRepository.findAll();
    }

    public Admin getAdminByEmail(String email) {
        return adminRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Admin not found with email: " + email));
    }

}
