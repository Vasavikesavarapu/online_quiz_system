package com.quiz.online_quiz_system.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
@Entity
@Table(name = "student_quiz_result")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StudentQuizResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // link student to result
    @ManyToOne
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne
    @JoinColumn(name="quiz_id")
    private Quiz quiz;

    private int totalMarks;
    private int score;
    private double percentage;
    private LocalDateTime attemptedAt;

    private boolean completed;
}
