package com.quiz.online_quiz_system.repository;

import com.quiz.online_quiz_system.entity.Quiz;
import com.quiz.online_quiz_system.entity.QuizSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.Query;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface QuizScheduleRepository extends JpaRepository<QuizSchedule, Long> {
    List<QuizSchedule> findByQuizQuizId(Long quizId);
    @Query("""
        SELECT qs FROM QuizSchedule qs WHERE qs.branch.branchName = :branchName
          AND qs.semester.semesterName = :semesterName AND qs.section.sectionName = :sectionName
    """)
    List<QuizSchedule> findForStudent(@Param("branchName") String branchName,
                                      @Param("semesterName") String semesterName,
                                      @Param("sectionName") String sectionName);

    List<QuizSchedule> findByStartTimeAfter(LocalDateTime now);
    List<QuizSchedule> findByEndTimeBefore(LocalDateTime now);
    List<QuizSchedule> findByQuiz(Quiz quiz);

}
