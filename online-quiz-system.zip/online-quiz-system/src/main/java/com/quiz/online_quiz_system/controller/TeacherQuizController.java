package com.quiz.online_quiz_system.controller;

import com.quiz.online_quiz_system.entity.*;
import com.quiz.online_quiz_system.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@RestController
@RequestMapping("/api/quizzes")
@CrossOrigin(origins = "http://localhost:3000")
public class TeacherQuizController {

    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    @Autowired
    private QuizRepository quizRepository;

    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private QuestionRepository questionRepository;

    @Autowired
    private QuestionOptionRepository optionRepository;

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private SemesterRepository semesterRepository;

    @Autowired
    private QuizScheduleRepository quizScheduleRepository;

    @Autowired
    private SectionRepository sectionRepository;

    // ✅ Create Quiz (NO scheduling)
    @PostMapping("/create")
    public ResponseEntity<?> createQuiz(@RequestBody Map<String, Object> data, Principal principal) {
        try {
            if (principal == null)
                return ResponseEntity.status(401).body(Map.of("success", false, "message", "Unauthorized"));

            String teacherEmail = principal.getName();
            Teacher teacher = teacherRepository.findByEmail(teacherEmail);
            if (teacher == null)
                return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Teacher not found"));

            String title = (String) data.get("title");
            String description = (String) data.get("description");
            Integer totalMarks = getIntValue(data.get("totalMarks"));
            Integer duration = getIntValue(data.get("duration"));

            if (title == null || title.trim().isEmpty() || duration == null)
                return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Title and Duration are required"));

            // Create quiz (no scheduling)
            Quiz quiz = Quiz.builder()
                    .title(title)
                    .description(description)
                    .totalMarks(totalMarks != null ? totalMarks : 0)
                    .duration(duration)
                    .teacher(teacher)
                    .createdAt(new Date())
                    .build();

            quizRepository.save(quiz);

            // Save questions and options if provided
            List<Map<String, Object>> questionsData = (List<Map<String, Object>>) data.get("questions");
            if (questionsData != null) {
                for (Map<String, Object> qData : questionsData) {
                    String questionText = (String) qData.get("questionText");
                    String questionType = (String) qData.get("questionType");
                    Integer marks = getIntValue(qData.get("marks"));
                    if (questionText == null || questionText.trim().isEmpty()) continue;

                    Question question = Question.builder()
                            .quiz(quiz)
                            .questionText(questionText)
                            .questionType(questionType != null ? questionType : "single_choice")
                            .marks(marks != null ? marks : 1)
                            .build();

                    questionRepository.save(question);

                    List<Map<String, Object>> optionsData = (List<Map<String, Object>>) qData.get("options");
                    if (optionsData != null) {
                        for (Map<String, Object> oData : optionsData) {
                            String optionText = (String) oData.get("optionText");
                            Boolean isCorrect = (Boolean) oData.get("isCorrect");
                            if (optionText == null || optionText.trim().isEmpty()) continue;

                            QuestionOption option = QuestionOption.builder()
                                    .question(question)
                                    .optionText(optionText)
                                    .isCorrect(isCorrect != null ? isCorrect : false)
                                    .build();
                            optionRepository.save(option);
                        }
                    }
                }
            }

            return ResponseEntity.ok(Map.of("success", true, "message", "Quiz created successfully", "quizId", quiz.getQuizId()));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().body(Map.of("success", false, "message", "Error creating quiz"));
        }
    }

    // ✅ Schedule Quiz (Separate Tab)
    @PutMapping("/schedule/{quizId}")
    public ResponseEntity<?> scheduleQuiz(
            @PathVariable Long quizId,
            @RequestBody Map<String, Object> data,
            Principal principal) {
        try {
            if (principal == null)
                return ResponseEntity.status(401).body(Map.of("success", false, "message", "Unauthorized"));

            String teacherEmail = principal.getName();
            Teacher teacher = teacherRepository.findByEmail(teacherEmail);
            if (teacher == null)
                return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Teacher not found"));

            Optional<Quiz> quizOpt = quizRepository.findById(quizId);
            if (quizOpt.isEmpty())
                return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Quiz not found"));

            Quiz quiz = quizOpt.get();
            if (!quiz.getTeacher().getId().equals(teacher.getId()))
                return ResponseEntity.status(403).body(Map.of("success", false, "message", "You can only schedule your own quizzes"));

            Long branchId = getLongValue(data.get("branchId"));
            Long semesterId = getLongValue(data.get("semesterId"));
            List<Integer> sectionIds = (List<Integer>) data.get("sectionIds");
            String startTimeStr = (String) data.get("startTime");
            String endTimeStr = (String) data.get("endTime");

            LocalDateTime startTime = LocalDateTime.parse(startTimeStr);
            LocalDateTime endTime = LocalDateTime.parse(endTimeStr);

            // 🕒 Validation 1: No past start times
            if (startTime.isBefore(LocalDateTime.now()))
                return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Start time cannot be in the past"));

            // 🕒 Validation 2: End must be after start
            if (endTime.isBefore(startTime))
                return ResponseEntity.badRequest().body(Map.of("success", false, "message", "End time must be after start time"));

            // 🕒 Validation 3: Match quiz duration
            long minutes = java.time.Duration.between(startTime, endTime).toMinutes();
            if (minutes != quiz.getDuration())
                return ResponseEntity.badRequest().body(Map.of("success", false, "message",
                        "Time difference must equal quiz duration (" + quiz.getDuration() + " mins)"));

            Branch branch = branchRepository.findById(branchId).orElse(null);
            Semester semester = semesterRepository.findById(semesterId).orElse(null);
            if (branch == null || semester == null)
                return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Invalid branch/semester"));

            // ✅ Create a QuizSchedule for each section
            for (Integer secId : sectionIds) {
                Section section = sectionRepository.findById(secId.longValue()).orElse(null);
                if (section != null) {
                    QuizSchedule schedule = QuizSchedule.builder()
                            .quiz(quiz)
                            .branch(branch)
                            .semester(semester)
                            .section(section)
                            .startTime(startTime)
                            .endTime(endTime)
                            .build();
                    quizScheduleRepository.save(schedule);
                }
            }

            return ResponseEntity.ok(Map.of("success", true, "message", "Quiz scheduled successfully for selected sections"));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().body(Map.of("success", false, "message", "Error scheduling quiz"));
        }
    }



    // ✅ Fetch quizzes created by logged teacher
    @GetMapping("/my-quizzes")
    public ResponseEntity<?> getQuizzesByTeacher(Principal principal) {
        if (principal == null)
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "Unauthorized"));

        String email = principal.getName();
        Teacher teacher = teacherRepository.findByEmail(email);
        if (teacher == null)
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Teacher not found"));

        List<Quiz> quizzes = quizRepository.findByTeacherIdWithQuestions(teacher.getId());

        List<Map<String, Object>> quizList = new ArrayList<>();
        for (Quiz quiz : quizzes) {
            Map<String, Object> quizMap = new HashMap<>();
            quizMap.put("quizId", quiz.getQuizId());
            quizMap.put("title", quiz.getTitle());
            quizMap.put("description", quiz.getDescription());
            quizMap.put("totalMarks", quiz.getTotalMarks());
            quizMap.put("duration", quiz.getDuration());
            quizMap.put("teacher", quiz.getTeacher());
            quizMap.put("questions", quiz.getQuestions());

            // Fetch all schedules for this quiz
            List<QuizSchedule> schedules = quizScheduleRepository.findByQuizQuizId(quiz.getQuizId());
            List<Map<String, Object>> scheduleList = new ArrayList<>();
            for (QuizSchedule s : schedules) {
                Map<String, Object> scheduleMap = new HashMap<>();
                scheduleMap.put("scheduleId", s.getScheduleId());
                scheduleMap.put("branch", s.getBranch());
                scheduleMap.put("semester", s.getSemester());
                scheduleMap.put("section", s.getSection());
                scheduleMap.put("startTime", s.getStartTime());
                scheduleMap.put("endTime", s.getEndTime());
                scheduleList.add(scheduleMap);
            }

            quizMap.put("schedules", scheduleList);
            quizList.add(quizMap);
        }

        return ResponseEntity.ok(Map.of("success", true, "quizzes", quizList));
    }

    // GET schedules for a specific quiz
    @GetMapping("/{quizId}/schedules")
    public ResponseEntity<?> getSchedulesForQuiz(@PathVariable Long quizId, Principal principal) {
        if (principal == null)
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "Unauthorized"));

        String email = principal.getName();
        Teacher teacher = teacherRepository.findByEmail(email);
        if (teacher == null)
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Teacher not found"));

        Optional<Quiz> quizOpt = quizRepository.findById(quizId);
        if (quizOpt.isEmpty())
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Quiz not found"));

        Quiz quiz = quizOpt.get();
        if (!quiz.getTeacher().getId().equals(teacher.getId()))
            return ResponseEntity.status(403).body(Map.of("success", false, "message", "You can only view your own quizzes"));

        List<QuizSchedule> schedules = quizScheduleRepository.findByQuizQuizId(quizId);
        List<Map<String, Object>> scheduleList = new ArrayList<>();
        for (QuizSchedule s : schedules) {
            Map<String, Object> scheduleMap = new HashMap<>();
            scheduleMap.put("scheduleId", s.getScheduleId());
            scheduleMap.put("branch", s.getBranch());
            scheduleMap.put("semester", s.getSemester());
            scheduleMap.put("section", s.getSection());
            scheduleMap.put("startTime", s.getStartTime());
            scheduleMap.put("endTime", s.getEndTime());
            scheduleList.add(scheduleMap);
        }

        return ResponseEntity.ok(Map.of("success", true, "schedules", scheduleList));
    }



    // ✅ Delete quiz
    @DeleteMapping("/{quizId}")
    public ResponseEntity<?> deleteQuiz(@PathVariable Long quizId, Principal principal) {
        if (principal == null)
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "Unauthorized"));

        String email = principal.getName();
        Teacher teacher = teacherRepository.findByEmail(email);
        if (teacher == null)
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Teacher not found"));

        Optional<Quiz> quizOpt = quizRepository.findById(quizId);
        if (quizOpt.isEmpty())
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Quiz not found"));

        Quiz quiz = quizOpt.get();
        if (!quiz.getTeacher().getId().equals(teacher.getId()))
            return ResponseEntity.status(403).body(Map.of("success", false, "message", "You can only delete your own quizzes"));

        // ✅ Check if quiz has schedules
        List<QuizSchedule> schedules = quizScheduleRepository.findByQuizQuizId(quizId);
        if (!schedules.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "This quiz is scheduled for some sections. Please remove schedules before deleting."
            ));
        }

        // ✅ If no schedules, delete the quiz safely
        quizRepository.delete(quiz);
        return ResponseEntity.ok(Map.of("success", true, "message", "Quiz deleted successfully"));
    }

    @DeleteMapping("/schedule/{scheduleId}")
    public ResponseEntity<?> deleteSchedule(@PathVariable Long scheduleId) {
        Optional<QuizSchedule> scheduleOpt = quizScheduleRepository.findById(scheduleId);
        if (scheduleOpt.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Schedule not found"));
        }

        quizScheduleRepository.delete(scheduleOpt.get());
        return ResponseEntity.ok(Map.of("success", true, "message", "Schedule deleted successfully"));
    }



    // 🔧 Helper methods
    private Long getLongValue(Object obj) {
        if (obj == null) return null;
        if (obj instanceof Integer) return ((Integer) obj).longValue();
        if (obj instanceof Long) return (Long) obj;
        try { return Long.valueOf(obj.toString()); } catch (Exception e) { return null; }
    }

    private Integer getIntValue(Object obj) {
        if (obj == null) return null;
        if (obj instanceof Integer) return (Integer) obj;
        if (obj instanceof Double) return ((Double) obj).intValue();
        try { return Integer.parseInt(obj.toString()); } catch (Exception e) { return null; }
    }
}
