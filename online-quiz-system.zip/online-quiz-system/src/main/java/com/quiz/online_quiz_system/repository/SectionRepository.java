package com.quiz.online_quiz_system.repository;

import com.quiz.online_quiz_system.entity.Section;
import com.quiz.online_quiz_system.entity.Semester;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface SectionRepository extends JpaRepository<Section, Long> {
    Section findBySectionNameAndSemester(String sectionName, Semester semester);
    List<Section> findBySemester(Semester semester);
}
