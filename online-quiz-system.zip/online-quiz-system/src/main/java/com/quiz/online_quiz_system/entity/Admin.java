package com.quiz.online_quiz_system.entity;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Admin {
    @Id
    private Integer adminId; // only 1 admin with fixed id

    private String name;

    @Column(unique = true, nullable = false)
    private String email;

    private String password;
}
