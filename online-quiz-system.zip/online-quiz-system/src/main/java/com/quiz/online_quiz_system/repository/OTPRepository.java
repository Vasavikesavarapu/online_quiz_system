package com.quiz.online_quiz_system.repository;

import com.quiz.online_quiz_system.entity.OTP;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

@Repository
public interface OTPRepository extends JpaRepository<OTP, Long> {
    OTP findByEmailAndOtpAndExpiryTimeAfter(String email, String otp, LocalDateTime currentTime);
    void deleteByEmail(String email);
}

