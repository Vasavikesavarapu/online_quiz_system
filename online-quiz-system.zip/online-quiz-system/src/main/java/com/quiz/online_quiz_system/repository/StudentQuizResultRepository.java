package com.quiz.online_quiz_system.repository;

import com.quiz.online_quiz_system.entity.StudentQuizResult;
import com.quiz.online_quiz_system.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentQuizResultRepository extends JpaRepository<StudentQuizResult, Long> {
    List<StudentQuizResult> findByStudent_email(String email);
}
