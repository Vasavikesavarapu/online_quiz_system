package com.quiz.online_quiz_system.controller;

import com.quiz.online_quiz_system.config.JwtUtil;
import com.quiz.online_quiz_system.entity.Admin;
import com.quiz.online_quiz_system.entity.OTP;
import com.quiz.online_quiz_system.entity.Teacher;
import com.quiz.online_quiz_system.entity.Student; // Import necessary entities
import com.quiz.online_quiz_system.repository.AdminRepository;
import com.quiz.online_quiz_system.repository.OTPRepository;
import com.quiz.online_quiz_system.repository.StudentRepository;
import com.quiz.online_quiz_system.repository.TeacherRepository;
import com.quiz.online_quiz_system.service.EmailService;
import com.quiz.online_quiz_system.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Random;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private StudentService studentService;

    @Autowired
    private OTPRepository otpRepository;

    @Autowired
    private EmailService emailService;


    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {
        String email = credentials.get("email");
        String password = credentials.get("password");

        if (email == null || password == null || email.trim().isEmpty() || password.trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Email and password are required"));
        }

        String trimmedEmail = email.trim();

        // Check Admin
        Admin admin = adminRepository.findByEmail(trimmedEmail).orElse(null);
        if (admin != null && passwordEncoder.matches(password, admin.getPassword())) {
            String token = jwtUtil.generateToken(admin.getEmail(), "ADMIN");
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Login successful",
                    "role", "admin",
                    "token", token
            ));
        }

        // Check Teacher
        Teacher teacher = teacherRepository.findByEmail(trimmedEmail.toLowerCase());

        if (teacher != null && passwordEncoder.matches(password, teacher.getPassword())) {
            String token = jwtUtil.generateToken(teacher.getEmail(), "TEACHER");
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Login successful",
                    "role", "teacher",
                    "token", token,
                    "teacher",Map.of(
                            "empId",teacher.getEmpId(),
                            "name",teacher.getName(),

                            "email",teacher.getEmail(),
                            "branch",teacher.getBranch().getBranchName()
                    )
            ));
        }

        // Check Student
        Student student = studentRepository.findByEmail(trimmedEmail);
        if (student != null && passwordEncoder.matches(password, student.getPassword())) {
            String token = jwtUtil.generateToken(student.getEmail(), "STUDENT");
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Login successful",
                    "role", "student",
                    "token", token,
                    "student", Map.of(
                            "stdId", student.getStdId(),
                            "name", student.getName(),
                            "email", student.getEmail(),
                            "branch", student.getBranch(),
                            "section", student.getSection(),
                            "semester", student.getSemester()
                    )
            ));
        }

        return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Invalid credentials"));
    }

    // --- Forgot Password ---
    @PostMapping("/student/forgot-password")
    public ResponseEntity<?> studentForgotPassword(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        if (email == null || email.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Email is required"
            ));
        }

        Student student = studentService.getStudentByEmail(email);
        if (student ==null) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "User not found"
            ));
        }


        // Generate OTP
        String otp = String.format("%06d", new Random().nextInt(999999));
        LocalDateTime expiryTime = LocalDateTime.now().plusMinutes(10);

        emailService.deleteAndSaveOTP(email,otp,expiryTime);

        try {
            emailService.sendOTP(email, otp);
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "OTP sent to your email"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Failed to send OTP"
            ));
        }
    }

    // --- Reset Password ---
    @PostMapping("/student/reset-password")
    public ResponseEntity<?> studentResetPassword(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        String otp = request.get("otp");
        String newPassword = request.get("newPassword");

        if (email == null || otp == null || newPassword == null) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Email, OTP, and new password are required"
            ));
        }

        OTP validOtp = otpRepository.findByEmailAndOtpAndExpiryTimeAfter(email, otp, LocalDateTime.now());
        if (validOtp == null) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Invalid or expired OTP"
            ));
        }

        Student student = studentService.getStudentByEmail(email);
            student.setPassword(passwordEncoder.encode(newPassword));
            studentService.saveStudent(student);
        emailService.deleteOTP(email); // remove used OTP

        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Password reset successfully"
        ));
    }

    @PostMapping("/teacher/forgot-password")
    public ResponseEntity<?> teacherForgotPassword(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        if (email == null || email.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Email is required"
            ));
        }

        Teacher teacher = teacherRepository.findByEmail(email);
        if ( teacher == null) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "User not found"
            ));
        }


        // Generate OTP
        String otp = String.format("%06d", new Random().nextInt(999999));
        LocalDateTime expiryTime = LocalDateTime.now().plusMinutes(10);

        emailService.deleteAndSaveOTP(email,otp,expiryTime);

        try {
            emailService.sendOTP(email, otp);
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "OTP sent to your email"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Failed to send OTP"
            ));
        }
    }

    // --- Reset Password ---
    @PostMapping("/teacher/reset-password")
    public ResponseEntity<?> teacherResetPassword(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        String otp = request.get("otp");
        String newPassword = request.get("newPassword");

        if (email == null || otp == null || newPassword == null) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Email, OTP, and new password are required"
            ));
        }

        OTP validOtp = otpRepository.findByEmailAndOtpAndExpiryTimeAfter(email, otp, LocalDateTime.now());
        if (validOtp == null) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Invalid or expired OTP"
            ));
        }

        Teacher teacher = teacherRepository.findByEmail(email);

        if(teacher != null){
            teacher.setPassword(passwordEncoder.encode(newPassword));
            teacherRepository.save(teacher);
        }
        emailService.deleteOTP(email); // remove used OTP

        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Password reset successfully"
        ));
    }

}