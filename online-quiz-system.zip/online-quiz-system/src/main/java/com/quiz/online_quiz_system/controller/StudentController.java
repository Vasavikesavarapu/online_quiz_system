package com.quiz.online_quiz_system.controller;

import com.quiz.online_quiz_system.dto.*;
import com.quiz.online_quiz_system.entity.*;
import com.quiz.online_quiz_system.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/student")
@CrossOrigin(origins = "http://localhost:3000")
public class StudentController {

    @Autowired
    private StudentService studentService;

    // Get student by email
    @GetMapping("/profile")
    public Student getStudent() {
        String email= SecurityContextHolder.getContext().getAuthentication().getName();
        return studentService.getStudentByEmail(email);
    }
    @GetMapping("/upcoming")
    public List<QuizSchedule> getUpcoming() {
        String email= SecurityContextHolder.getContext().getAuthentication().getName();
        Student s = studentService.getStudentByEmail(email);
        return studentService.getUpcomingQuizzes(s);
    }

    @GetMapping("/completed")
    public List<QuizSchedule> getCompleted() {
        String email= SecurityContextHolder.getContext().getAuthentication().getName();
        Student s = studentService.getStudentByEmail(email);
        return studentService.getCompletedQuizzes(s);
    }

    // Save quiz result
    @PostMapping("/result")
    public StudentQuizResult saveResult(@RequestBody StudentQuizResult result) {
        return studentService.saveResult(result);
    }

    @PutMapping("/profile")
    public Student updateProfile(@RequestBody Student updatedStudent) {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return studentService.updateStudentProfile(email, updatedStudent);
    }
    // Get results by student
    @GetMapping("/results")
    public List<StudentQuizResult> getResults() {
        String email= SecurityContextHolder.getContext().getAuthentication().getName();
        return studentService.getResultsByStudent(email);
    }

    @PostMapping("/start/{quizId}")
    public QuizAttempt startAttempt(@PathVariable Long quizId) {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return studentService.startQuizAttempt(email, quizId);
    }

    @PostMapping("/submit/{quizId}")
    public QuizAttempt submitAttempt(@PathVariable Long quizId, @RequestBody List<AnswerRequest> answers) {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return studentService.submitQuizAttempt(email, quizId, answers);
    }
    @GetMapping("/{quizId}") // Use {quizId} directly under the class's @RequestMapping("/api/student")
    public Quiz getQuizDetails(@PathVariable Long quizId) {
        // We'll add this method to StudentService in Step 2
        return studentService.getQuizById(quizId);
    }


}
