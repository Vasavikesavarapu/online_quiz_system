package com.quiz.online_quiz_system.controller;

import com.quiz.online_quiz_system.entity.Quiz;
import com.quiz.online_quiz_system.entity.QuizAttempt;
import com.quiz.online_quiz_system.repository.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/teacher/analytics")
public class QuizAnalyticsController {

    @Autowired
    private QuizRepository quizRepository;

    @Autowired
    private QuizAttemptRepository attemptRepository;

    // 🧑‍🏫 TEACHER: View leaderboard for a quiz
    @GetMapping("/teacher/{quizId}/results")
    public ResponseEntity<?> getQuizResultsForTeacher(@PathVariable Long quizId, HttpServletRequest request) {
        String role = (String) request.getAttribute("role");
        String email = (String) request.getAttribute("email");

        if (!"TEACHER".equalsIgnoreCase(role)) {
            return ResponseEntity.status(403).body(Map.of("message", "Access denied"));
        }

        Quiz quiz = quizRepository.findById(quizId)
                .orElseThrow(() -> new RuntimeException("Quiz not found"));

        List<QuizAttempt> attempts = attemptRepository.findByQuizOrderByScoreDesc(quiz);

        List<Map<String, Object>> leaderboard = new ArrayList<>();
        int rank = 1;
        for (QuizAttempt a : attempts) {
            leaderboard.add(Map.of(
                    "rank", rank++,
                    "studentName", a.getStudent().getName(),
                    "studentId", a.getStudent().getStdId(),
                    "score", a.getScore(),
                    "correct", a.getCorrectAnswers(),
                    "total", a.getTotalQuestions()
            ));
        }

        return ResponseEntity.ok(Map.of(
                "quizId", quiz.getQuizId(),
                "quizTitle", quiz.getTitle(),
                "leaderboard", leaderboard
        ));
    }

    @GetMapping("/{quizId}")
    public ResponseEntity<?> getQuizAnalytics(@PathVariable Long quizId, HttpServletRequest request) {
        String role = (String) request.getAttribute("role");
        if (!"TEACHER".equalsIgnoreCase(role)) {
            return ResponseEntity.status(403).body(Map.of("message", "Access denied"));
        }

        var quiz = quizRepository.findById(quizId).orElseThrow();
        var attempts = attemptRepository.findByQuiz_QuizId(quizId);

        List<Map<String, Object>> results = new ArrayList<>();
        for (var attempt : attempts) {
            results.add(Map.of(
                    "student", attempt.getStudent().getName(),
                    "score", attempt.getScore(),
                    "time", attempt.getAttemptTime()
            ));
        }

        return ResponseEntity.ok(Map.of(
                "quizTitle", quiz.getTitle(),
                "totalAttempts", attempts.size(),
                "results", results
        ));
    }
}
