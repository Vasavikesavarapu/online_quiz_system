package com.quiz.online_quiz_system.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "teacher")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Teacher {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String empId; // Unique ID (already correct)

    @Column(nullable = false)
    private String name;

    @Column(unique = true, nullable = false)
    private String email; // Unique email (already correct)

    // 🛑 CRITICAL CHANGE: Replace String department with ManyToOne relationship to Branch
    @ManyToOne
    @JoinColumn(name = "branch_id", nullable = false) // Foreign key column
    private Branch branch;

    @Column(nullable = false)
    private String password;
}