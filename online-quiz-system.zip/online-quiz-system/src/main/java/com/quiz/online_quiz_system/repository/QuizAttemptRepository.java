package com.quiz.online_quiz_system.repository;

import com.quiz.online_quiz_system.entity.Quiz;
import com.quiz.online_quiz_system.entity.QuizAttempt;
import com.quiz.online_quiz_system.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface QuizAttemptRepository extends JpaRepository<QuizAttempt, Long> {
    List<QuizAttempt> findByQuiz_QuizIdAndStudentEmail(Long quizId,String email);
    List<QuizAttempt> findByStudentEmail(String email);
    QuizAttempt findByStudentAndQuiz(Student student, Quiz quiz);
    List<QuizAttempt> findByStudent(Student student);
    List<QuizAttempt> findByQuizOrderByScoreDesc(Quiz quiz);
    List<QuizAttempt> findByQuiz_QuizId(Long quizId);

}
