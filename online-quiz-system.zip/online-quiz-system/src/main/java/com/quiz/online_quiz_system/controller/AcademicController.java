package com.quiz.online_quiz_system.controller;

import com.quiz.online_quiz_system.entity.Branch;
import com.quiz.online_quiz_system.entity.Semester;
import com.quiz.online_quiz_system.entity.Section;
import com.quiz.online_quiz_system.repository.BranchRepository;
import com.quiz.online_quiz_system.repository.SemesterRepository;
import com.quiz.online_quiz_system.repository.SectionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/academic/")
@CrossOrigin(origins = "http://localhost:3000")
public class AcademicController {

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private SemesterRepository semesterRepository;

    @Autowired
    private SectionRepository sectionRepository;

    // ---------------- Branch CRUD ----------------

    @PostMapping("/branches")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> createBranch(@RequestBody Map<String, String> data) {
        String branchName = data.get("branchName");

        if (branchName == null || branchName.isBlank())
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Branch name required"));

        if (branchRepository.findByBranchName(branchName) != null)
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Branch already exists"));

        Branch branch = Branch.builder().branchName(branchName).build();
        branchRepository.save(branch);

        return ResponseEntity.ok(Map.of("success", true, "branch", branch));
    }

    @GetMapping("/branches")
    @PreAuthorize("hasAnyRole('ADMIN','TEACHER','STUDENT')")
    public ResponseEntity<List<Branch>> getAllBranches() {
        return ResponseEntity.ok(branchRepository.findAll());
    }

    @PutMapping("/branches/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> updateBranch(@PathVariable Long id, @RequestBody Map<String, String> data) {
        Branch branch = branchRepository.findById(id).orElse(null);
        if (branch == null)
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Branch not found"));

        String branchName = data.get("branchName");
        if (branchName == null || branchName.isBlank())
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Branch name required"));

        Branch existing = branchRepository.findByBranchName(branchName);
        if (existing != null && !existing.getBranchId().equals(id))
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Branch already exists"));

        branch.setBranchName(branchName);
        branchRepository.save(branch);

        return ResponseEntity.ok(Map.of("success", true, "branch", branch));
    }

    @DeleteMapping("/branches/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteBranch(@PathVariable Long id) {
        if (!branchRepository.existsById(id))
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Branch not found"));

        branchRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("success", true, "message", "Branch deleted successfully"));
    }

    // ---------------- Semester CRUD ----------------

    @PostMapping("/semesters")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> createSemester(@RequestBody Map<String, String> data) {
        String semesterName = data.get("semesterName");
        Long branchId = Long.parseLong(data.get("branchId"));

        Branch branch = branchRepository.findById(branchId).orElse(null);
        if (branch == null) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Branch not found"));
        }

        Semester semester = Semester.builder()
                .semesterName(semesterName)
                .branch(branch)
                .build();

        semesterRepository.save(semester);
        return ResponseEntity.ok(Map.of("success", true, "semester", semester));
    }

    @GetMapping("/semesters")
    @PreAuthorize("hasAnyRole('ADMIN','TEACHER','STUDENT')")
    public ResponseEntity<List<Semester>> getAllSemesters() {
        return ResponseEntity.ok(semesterRepository.findAll());
    }

    @PutMapping("/semesters/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> updateSemester(@PathVariable Long id, @RequestBody Map<String, String> data) {
        Semester semester = semesterRepository.findById(id).orElse(null);
        if (semester == null)
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Semester not found"));

        String semesterName = data.get("semesterName");
        if (semesterName == null || semesterName.isBlank())
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Semester name required"));

        Semester existing = semesterRepository.findBySemesterNameAndBranch(semesterName, semester.getBranch());
        if (existing != null && !existing.getSemesterId().equals(id))
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Semester already exists"));

        semester.setSemesterName(semesterName);
        semesterRepository.save(semester);

        return ResponseEntity.ok(Map.of("success", true, "semester", semester));
    }

    @DeleteMapping("/semesters/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteSemester(@PathVariable Long id) {
        if (!semesterRepository.existsById(id))
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Semester not found"));

        semesterRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("success", true, "message", "Semester deleted successfully"));
    }

    // ---------------- Section CRUD ----------------

    @PostMapping("/sections")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> createSection(@RequestBody Map<String, String> data) {
        String sectionName = data.get("sectionName");
        Long semesterId = Long.parseLong(data.get("semesterId"));

        Semester semester = semesterRepository.findById(semesterId).orElse(null);
        if (semester == null) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Semester not found"));
        }

        if (sectionRepository.findBySectionNameAndSemester(sectionName, semester) != null) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Section already exists for this semester"));
        }

        Section section = Section.builder()
                .sectionName(sectionName)
                .semester(semester)
                .build();

        sectionRepository.save(section);

        return ResponseEntity.ok(Map.of("success", true, "section", section));
    }

    @GetMapping("/sections")
    @PreAuthorize("hasAnyRole('ADMIN','TEACHER','STUDENT')")
    public ResponseEntity<List<Section>> getAllSections() {
        return ResponseEntity.ok(sectionRepository.findAll());
    }

    @PutMapping("/sections/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> updateSection(@PathVariable Long id, @RequestBody Map<String, String> data) {
        Section section = sectionRepository.findById(id).orElse(null);
        if (section == null)
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Section not found"));

        String sectionName = data.get("sectionName");
        if (sectionName == null || sectionName.isBlank())
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Section name required"));

        Section existing = sectionRepository.findBySectionNameAndSemester(sectionName, section.getSemester());
        if (existing != null && !existing.getSectionId().equals(id))
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Section already exists for this semester"));

        section.setSectionName(sectionName);
        sectionRepository.save(section);

        return ResponseEntity.ok(Map.of("success", true, "section", section));
    }

    @DeleteMapping("/sections/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteSection(@PathVariable Long id) {
        if (!sectionRepository.existsById(id))
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Section not found"));

        sectionRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("success", true, "message", "Section deleted successfully"));
    }
}
