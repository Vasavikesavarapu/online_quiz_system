package com.quiz.online_quiz_system.repository;

import com.quiz.online_quiz_system.entity.Branch;
import com.quiz.online_quiz_system.entity.Semester;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SemesterRepository extends JpaRepository<Semester, Long> {
    Semester findBySemesterNameAndBranch(String semesterName, Branch branch);
    List<Semester> findByBranch(Branch branch);
}
