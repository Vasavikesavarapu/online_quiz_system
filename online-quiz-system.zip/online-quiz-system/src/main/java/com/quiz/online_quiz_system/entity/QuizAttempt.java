package com.quiz.online_quiz_system.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="quiz_attempt")
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QuizAttempt {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "quiz_id", nullable = false)
    private Quiz quiz;

    @ManyToOne
    @JoinColumn(name = "std_id", nullable = false)
    private Student student;

    private int totalQuestions;
    private int correctAnswers;
    private int score;
    private long timeTaken;
    private Double percentage; // nullable; optional

    @Column(name="is_terminated",nullable = false)
    private boolean isTerminated;

    @Column(nullable = false)
    private boolean submitted;

    private LocalDateTime attemptTime;
    private LocalDateTime endTime;

    @OneToMany(mappedBy = "quizAttempt", cascade = CascadeType.ALL)
    @Builder.Default
    @JsonManagedReference
    private List<StudentAnswer> answers = new ArrayList<>();

}
