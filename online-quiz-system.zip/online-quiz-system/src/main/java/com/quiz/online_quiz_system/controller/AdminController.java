package com.quiz.online_quiz_system.controller;

import com.quiz.online_quiz_system.entity.Student;
import com.quiz.online_quiz_system.entity.Teacher;
import com.quiz.online_quiz_system.entity.Branch;
import com.quiz.online_quiz_system.entity.Semester;
import com.quiz.online_quiz_system.entity.Section;

import com.quiz.online_quiz_system.repository.BranchRepository;
import com.quiz.online_quiz_system.repository.SemesterRepository;
import com.quiz.online_quiz_system.repository.SectionRepository;
import com.quiz.online_quiz_system.repository.StudentRepository;
import com.quiz.online_quiz_system.repository.TeacherRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.InputStream;
import java.util.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:3000")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    @Autowired private StudentRepository studentRepository;
    @Autowired private TeacherRepository teacherRepository;
    @Autowired private BranchRepository branchRepository;
    @Autowired private SemesterRepository semesterRepository;
    @Autowired private SectionRepository sectionRepository;
    @Autowired private PasswordEncoder passwordEncoder;

    // ---------------- STUDENTS ----------------
    @GetMapping("/students")
    public ResponseEntity<List<Student>> getAllStudents() {
        return ResponseEntity.ok(studentRepository.findAll());
    }

    @PostMapping("/students")
    public ResponseEntity<?> addStudent(@RequestBody Map<String, String> data) {
        try {
            String stdId = data.get("stdId");
            String name = data.get("name");
            String email = data.get("email");
            String branchName = data.get("branch");
            String semesterName = data.get("semester"); // use 'semester' key
            String sectionName = data.get("section");   // use 'section' key

            if (stdId == null || name == null || email == null || branchName == null || semesterName == null || sectionName == null)
                return ResponseEntity.badRequest().body(Map.of("success", false, "message", "All fields are required"));

            if (studentRepository.findByStdId(stdId) != null)
                return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Student ID exists"));
            if (studentRepository.findByEmail(email) != null)
                return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Email exists"));

            Branch branch = branchRepository.findByBranchName(branchName);
            if (branch == null) return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Invalid Branch"));

            Semester semester = semesterRepository.findBySemesterNameAndBranch(semesterName, branch);
            if (semester == null) return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Invalid Semester"));

            Section section = sectionRepository.findBySectionNameAndSemester(sectionName, semester);
            if (section == null) return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Invalid Section"));

            String password = data.getOrDefault("password", "Student@2024!");
            Student student = new Student();
            student.setStdId(stdId);
            student.setName(name);
            student.setEmail(email);
            student.setBranch(branch.getBranchName());
            student.setSemester(semester.getSemesterName());
            student.setSection(section.getSectionName());
            student.setPassword(passwordEncoder.encode(password));

            studentRepository.save(student);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "student", student,
                    "defaultPassword", password
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("success", false, "message", e.getMessage()));
        }
    }


    @PutMapping("/students/{id}")
    public ResponseEntity<?> updateStudent(@PathVariable Long id, @RequestBody Map<String, String> data) {
        Student student = studentRepository.findById(id).orElse(null);
        if (student == null)
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Student not found"));

        String name = data.get("name");
        String email = data.get("email");
        String branchName = data.get("branch");
        String semesterName = data.get("semester"); // ← change here
        String sectionName = data.get("section");   // ← change here

        Branch branch = branchRepository.findByBranchName(branchName);
        if (branch == null) return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Invalid Branch"));

        Semester semester = semesterRepository.findBySemesterNameAndBranch(semesterName, branch);
        if (semester == null) return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Invalid Semester"));

        Section section = sectionRepository.findBySectionNameAndSemester(sectionName, semester);
        if (section == null) return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Invalid Section"));

        student.setName(name);
        student.setEmail(email);
        student.setBranch(branch.getBranchName());
        student.setSemester(semester.getSemesterName());
        student.setSection(section.getSectionName());

        if (data.containsKey("password") && !data.get("password").isEmpty())
            student.setPassword(passwordEncoder.encode(data.get("password")));

        studentRepository.save(student);
        return ResponseEntity.ok(Map.of("success", true, "student", student));
    }


    @DeleteMapping("/students/{id}")
    public ResponseEntity<?> deleteStudent(@PathVariable Long id) {
        if (!studentRepository.existsById(id))
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Student not found"));
        studentRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("success", true, "message", "Student deleted successfully"));
    }

    @PostMapping("/students/upload-excel")
    public ResponseEntity<?> uploadStudentExcel(@RequestParam("file") MultipartFile file) {
        List<String> errors = new ArrayList<>();
        int uploaded = 0;

        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                try {
                    String stdId = getCellValue(row, 0);
                    String name = getCellValue(row, 1);
                    String email = getCellValue(row, 2);
                    String branchName = getCellValue(row, 3);
                    String semesterName = getCellValue(row, 4);
                    String sectionName = getCellValue(row, 5);

                    if (studentRepository.findByStdId(stdId) != null || studentRepository.findByEmail(email) != null) {
                        errors.add("Row " + (i + 1) + ": Duplicate Student ID or Email");
                        continue;
                    }

                    Branch branch = branchRepository.findByBranchName(branchName);
                    if (branch == null) { errors.add("Row " + (i + 1) + ": Invalid Branch"); continue; }

                    Semester semester = semesterRepository.findBySemesterNameAndBranch(semesterName, branch);
                    if (semester == null) { errors.add("Row " + (i + 1) + ": Invalid Semester"); continue; }

                    Section section = sectionRepository.findBySectionNameAndSemester(sectionName, semester);
                    if (section == null) { errors.add("Row " + (i + 1) + ": Invalid Section"); continue; }

                    Student student = new Student();
                    student.setStdId(stdId);
                    student.setName(name);
                    student.setEmail(email);
                    student.setBranch(branch.getBranchName());
                    student.setSemester(semester.getSemesterName());
                    student.setSection(section.getSectionName());
                    student.setPassword(passwordEncoder.encode("Student@2024!"));

                    studentRepository.save(student);
                    uploaded++;

                } catch (Exception e) {
                    errors.add("Row " + (i + 1) + ": " + e.getMessage());
                }
            }

            return ResponseEntity.ok(Map.of("success", true, "uploaded", uploaded, "errors", errors));

        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("success", false, "message", e.getMessage()));
        }
    }


    // ---------------- TEACHERS ----------------
    @GetMapping("/teachers")
    public ResponseEntity<List<Teacher>> getAllTeachers() {
        return ResponseEntity.ok(teacherRepository.findAll());
    }

    @PostMapping("/teachers")
    public ResponseEntity<?> addTeacher(@RequestBody Map<String, String> data) {
        try {
            String empId = data.get("empId");
            String name = data.get("name");
            String email = data.get("email");
            String branchName = data.get("branch");

            // Validate required fields
            if (empId == null || name == null || email == null || branchName == null) {
                return ResponseEntity.badRequest()
                        .body(Map.of("success", false, "message", "All fields are required"));
            }

            // Check for duplicates
            if (teacherRepository.findByEmpId(empId) != null) {
                return ResponseEntity.badRequest()
                        .body(Map.of("success", false, "message", "Employee ID exists"));
            }
            if (teacherRepository.findByEmail(email) != null) {
                return ResponseEntity.badRequest()
                        .body(Map.of("success", false, "message", "Email exists"));
            }

            // Find branch
            Branch branch = branchRepository.findByBranchName(branchName);
            if (branch == null) {
                return ResponseEntity.badRequest()
                        .body(Map.of("success", false, "message", "Invalid Branch"));
            }

            // Create teacher
            Teacher teacher = Teacher.builder()
                    .empId(empId)
                    .name(name)
                    .email(email.trim().toLowerCase())
                    .branch(branch)
                    .password(passwordEncoder.encode("TeachSecure@2024!")) // default password
                    .build();

            teacherRepository.save(teacher);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "teacher", teacher,
                    "defaultPassword", "TeachSecure@2024!"
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("success", false, "message", e.getMessage()));
        }
    }


    @PutMapping("/teachers/{id}")
    public ResponseEntity<?> updateTeacher(@PathVariable Long id, @RequestBody Map<String, String> data) {
        Teacher teacher = teacherRepository.findById(id).orElse(null);
        if (teacher == null)
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Teacher not found"));

        teacher.setName(data.get("name"));
        teacher.setEmail(data.get("email").trim().toLowerCase());

        if (data.containsKey("branchId"))
            teacher.setBranch(branchRepository.findById(Long.parseLong(data.get("branchId"))).orElse(teacher.getBranch()));

        if (data.containsKey("password") && !data.get("password").isEmpty())
            teacher.setPassword(passwordEncoder.encode(data.get("password")));

        teacherRepository.save(teacher);
        return ResponseEntity.ok(Map.of("success", true, "teacher", teacher));
    }

    @DeleteMapping("/teachers/{id}")
    public ResponseEntity<?> deleteTeacher(@PathVariable Long id) {
        if (!teacherRepository.existsById(id))
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Teacher not found"));
        teacherRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("success", true, "message", "Teacher deleted successfully"));
    }

    @PostMapping("/teachers/upload-excel")
    public ResponseEntity<?> uploadTeacherExcel(@RequestParam("file") MultipartFile file) {
        List<String> errors = new ArrayList<>();
        int uploaded = 0;

        // Preload branches into a map for faster lookup
        Map<String, Branch> branchMap = new HashMap<>();
        branchRepository.findAll().forEach(b -> branchMap.put(b.getBranchName().trim().toLowerCase(), b));

        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);

            for (int i = 1; i <= sheet.getLastRowNum(); i++) { // skip header
                Row row = sheet.getRow(i);
                if (row == null) continue;

                try {
                    String empId = getCellValue(row, 0);
                    String name = getCellValue(row, 1);
                    String email = getCellValue(row, 2);
                    String branchName = getCellValue(row, 3).trim().toLowerCase();

                    // Validate required fields
                    if (empId.isEmpty() || name.isEmpty() || email.isEmpty() || branchName.isEmpty()) {
                        errors.add("Row " + (i + 1) + ": Missing fields");
                        continue;
                    }

                    // Check for duplicates
                    if (teacherRepository.findByEmpId(empId) != null || teacherRepository.findByEmail(email) != null) {
                        errors.add("Row " + (i + 1) + ": Duplicate Employee ID or Email");
                        continue;
                    }

                    Branch branch = branchMap.get(branchName);
                    if (branch == null) {
                        errors.add("Row " + (i + 1) + ": Branch not found");
                        continue;
                    }

                    // Create and save teacher
                    Teacher teacher = Teacher.builder()
                            .empId(empId)
                            .name(name)
                            .email(email.trim().toLowerCase())
                            .branch(branch)
                            .password(passwordEncoder.encode("TeachSecure@2024!")) // default password
                            .build();

                    teacherRepository.save(teacher);
                    uploaded++;

                } catch (Exception e) {
                    errors.add("Row " + (i + 1) + ": " + e.getMessage());
                }
            }

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "uploaded", uploaded,
                    "errors", errors
            ));

        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of(
                    "success", false,
                    "message", e.getMessage()
            ));
        }
    }

    /** Utility method: safely get cell value as string */
    private String getCellValue(Row row, int index) {
        Cell cell = row.getCell(index);
        if (cell == null) return "";
        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue().trim();
            case NUMERIC -> String.valueOf((long) cell.getNumericCellValue());
            case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
            case FORMULA -> cell.getCellFormula();
            default -> "";
        };
    }
}
