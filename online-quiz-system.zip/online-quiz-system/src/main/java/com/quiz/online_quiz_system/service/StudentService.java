package com.quiz.online_quiz_system.service;
import com.quiz.online_quiz_system.dto.*;
import com.quiz.online_quiz_system.entity.*;
import com.quiz.online_quiz_system.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

import java.util.ArrayList;
import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private QuizScheduleRepository quizScheduleRepository;

    @Autowired
    private StudentQuizResultRepository studentQuizResultRepository;

    @Autowired
    private QuizAttemptRepository quizAttemptRepository;

    @Autowired
    private QuizRepository quizRepository;

    @Autowired
    private QuestionRepository questionRepository;


    // Get student by email
    public Student getStudentByEmail(String email) {
        return studentRepository.findByEmail(email);
    }

    public Quiz getQuizById(Long quizId) {
        return quizRepository.findById(quizId)
                .orElseThrow(() -> new RuntimeException("Quiz not found with ID: " + quizId));
    }


    // Update student profile
    public Student updateStudentProfile(String email, Student updatedData) {
        Student existing = studentRepository.findByEmail(email);
        if (existing == null) {
            throw new RuntimeException("Student not found with email: " + email);
        }

        // update editable fields
        existing.setName(updatedData.getName());
        existing.setBranch(updatedData.getBranch());
        existing.setSection(updatedData.getSection());
        existing.setSemester(updatedData.getSemester());

        return studentRepository.save(existing);
    }

    public List<QuizSchedule> getUpcomingQuizzes(Student student) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime oneHourLater = now.plusHours(1);
        return quizScheduleRepository.findForStudent(
                        student.getBranch(),
                        student.getSemester(),
                        student.getSection()
                ).stream()
                .filter(q -> q.getStartTime().isBefore(oneHourLater) && q.getEndTime().isAfter(now))
                .toList();
    }

    public List<QuizSchedule> getCompletedQuizzes(Student student) {
        LocalDateTime now = LocalDateTime.now();
        return quizScheduleRepository.findForStudent(
                        student.getBranch(),
                        student.getSemester(),
                        student.getSection()
                ).stream()
                .filter(q -> q.getEndTime().isBefore(now))
                .toList();
    }

    // Save quiz result
    public StudentQuizResult saveResult(StudentQuizResult result) {
        result.setAttemptedAt(LocalDateTime.now());
        result.setCompleted(true);
        return studentQuizResultRepository.save(result);
    }

    // Get student results
    public List<StudentQuizResult> getResultsByStudent(String email) {
        return studentQuizResultRepository.findByStudent_email(email);
    }

    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }

    public QuizAttempt startQuizAttempt(String email, Long quizId) {
        Student student = studentRepository.findByEmail(email);
        if (student == null) {
            throw new RuntimeException("Student not found");
        }

        Quiz quiz = quizRepository.findById(quizId)
                .orElseThrow(() -> new RuntimeException("Quiz not found"));

        // ✅ Check if already attempted
        List<QuizAttempt> existing = quizAttemptRepository.findByQuiz_QuizIdAndStudentEmail(quizId, email);
        if (!existing.isEmpty()) {
            QuizAttempt prev = existing.get(0);
            if (prev.isSubmitted()) {
                throw new RuntimeException("You have already completed this quiz");
            } else {
                return prev; // Resume unfinished attempt
            }
        }

        // ✅ Verify quiz is still active
        List<QuizSchedule> schedules = quizScheduleRepository.findByQuiz(quiz);
        QuizSchedule schedule = schedules.isEmpty()?null:schedules.get(0);
        LocalDateTime now = LocalDateTime.now();
        if (schedule != null && (now.isBefore(schedule.getStartTime()) || now.isAfter(schedule.getEndTime()))) {
            throw new RuntimeException("Quiz is not active now");
        }

        // ✅ Create new attempt
        QuizAttempt attempt = QuizAttempt.builder()
                .quiz(quiz)
                .student(student)
                .attemptTime(LocalDateTime.now())
                .submitted(false)
                .isTerminated(false)
                .build();

        return quizAttemptRepository.save(attempt);
    }

    public QuizAttempt submitQuizAttempt(String email, Long quizId, List<AnswerRequest> answers) {
        Student student = studentRepository.findByEmail(email);
        if (student == null) {
            throw new RuntimeException("Student not found");
        }

        QuizAttempt attempt = quizAttemptRepository.findByQuiz_QuizIdAndStudentEmail(quizId, email)
                .stream().findFirst()
                .orElseThrow(() -> new RuntimeException("No active quiz attempt found"));

        if (attempt.isSubmitted()) {
            throw new RuntimeException("This quiz is already submitted");
        }

        int correct = 0;
        List<StudentAnswer> studentAnswers = new ArrayList<>();

        for (AnswerRequest a : answers) {
            Question question = questionRepository.findById(a.getQuestionId())
                    .orElseThrow(() -> new RuntimeException("Question not found"));
            boolean isCorrect = question.getOptions().stream()
                    .anyMatch(opt -> opt.isCorrect() &&
                            opt.getOptionText().equalsIgnoreCase(a.getAnswer()));

            if (isCorrect) correct++;

            studentAnswers.add(StudentAnswer.builder()
                    .quizAttempt(attempt)
                    .question(question)
                    .answer(a.getAnswer())
                    .isCorrect(isCorrect)
                    .build());
        }

        int total = answers.size();
        int score = studentAnswers.stream()
                .filter(StudentAnswer::isCorrect)
                .mapToInt(sa -> sa.getQuestion().getMarks())
                .sum();
        double percentage = (score * 100.0) / total;

        attempt.setAnswers(studentAnswers);
        attempt.setSubmitted(true);
        attempt.setEndTime(LocalDateTime.now());
        attempt.setTotalQuestions(total);
        attempt.setCorrectAnswers(correct);
        attempt.setScore(score);
        attempt.setPercentage(percentage);

        return quizAttemptRepository.save(attempt);
    }


}
