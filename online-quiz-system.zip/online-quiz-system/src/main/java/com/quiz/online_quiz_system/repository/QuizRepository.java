package com.quiz.online_quiz_system.repository;

import com.quiz.online_quiz_system.entity.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface QuizRepository extends JpaRepository<Quiz, Long> {

    // Original method (might cause L.I.E. on 'questions' field during serialization)
    List<Quiz> findByTeacherId(Long teacherId);

    // ✅ RECOMMENDED: New method using JOIN FETCH to eagerly load questions, preventing L.I.E.
    @Query("SELECT DISTINCT q FROM Quiz q LEFT JOIN FETCH q.questions WHERE q.teacher.id = :teacherId")
    List<Quiz> findByTeacherIdWithQuestions(@Param("teacherId") Long teacherId);

    @Query("SELECT q FROM Quiz q " +
            "WHERE q.branch.id = :branchId " +
            "AND q.semester.id = :semesterId " +

            "AND q.section.id = :sectionId " +
            "AND q.endTime >= :currentTime")
    List<Quiz> findAvailableQuizzesByStructure(
            @Param("branchId") Long branchId,
            @Param("semesterId") Long semesterId,
            @Param("sectionId") Long sectionId,
            @Param("currentTime") LocalDateTime currentTime);

}