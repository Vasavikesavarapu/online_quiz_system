package com.quiz.online_quiz_system.config;

import com.quiz.online_quiz_system.entity.Admin;
import com.quiz.online_quiz_system.repository.AdminRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class AdminInitConfig {

    @Bean
    CommandLineRunner initAdmin(AdminRepository adminRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            if (adminRepository.count() == 0) {
                Admin admin = Admin.builder()
                        .adminId(1) // fixed single admin
                        .name("admin") // this will be the username
                        .email("admin@gmail.com")
                        .password(passwordEncoder.encode("Admin@2025"))
                        .build();

                adminRepository.save(admin);
                System.out.println("✅ Default admin created -> name: admin | email: admin@gmail.com | password: Admin@2025");
            }
        };
    }
}
